package com.admin;

public @interface WebServlet {

}
